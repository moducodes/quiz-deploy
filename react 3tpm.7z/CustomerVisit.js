import React, { Component } from 'react';

class CustomerVisit extends Component {
  deleteVisit(){
    let username = this.props.visit.username;
    this.props.onDelete(username);
  }
  render() {
    return (
        <div>
            Name: {this.props.visit.username}<br/>
            Email Id: {this.props.visit.emailid}<br/>
            Mobile Number: {this.props.visit.mobilenumber}<br/>
            Address: {this.props.visit.address}<br/>
            Description/Purpose: {this.props.visit.purposeofvisit}<br/>
            Date of Visit: {this.props.visit.dateofvisit}&nbsp;&nbsp;&nbsp;
            <input type="button" value="Delete" onClick={this.deleteVisit.bind(this)}></input>
        </div>
    );
  }
}

export default CustomerVisit;