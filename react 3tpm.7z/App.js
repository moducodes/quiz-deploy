import React, { Component } from 'react';
import './App.css';
import RegForm from './RegForm'
import CustomerVisit from './CustomerVisit'

class App extends Component {
  constructor(){
    super();
    this.state={
      visitLog:[]
    }
  }

  handleLogIn(visit){
    let visits = this.state.visitLog;
    visits.push(visit);
    this.setState({
      visitLog: visits
    })
  }

  deleteVisit(uname){
    let visits = this.state.visitLog;
    let index = visits.findIndex(oneVisit => oneVisit.username == uname);
    
    visits.splice(index,1);
    this.setState({
      visitLog: visits
    })
  }

  render() {
    let customerVisits;

    if(this.state.visitLog.length != 0){
    customerVisits = this.state.visitLog.map(
      oneVisit => {
        return(
          <div>
          <CustomerVisit key={oneVisit.username} visit={oneVisit} onDelete={this.deleteVisit.bind(this)}/><br/>
          </div>
        )
      }
    );}

    return (
      <div>
      <RegForm onLogIn={this.handleLogIn.bind(this)}></RegForm>
      <div>
        {customerVisits}
      </div>
      </div>

    );
  }
}

export default App;
