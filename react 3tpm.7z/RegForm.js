import React, { Component } from 'react';
import './RegForm.css';

class RegForm extends Component {
    constructor(){
        super();
        this.state={
            newCust:{}
        }
    }

    handleClick(){
        this.setState({
            newCust:{
                username: this.refs.uname.value,
                emailid: this.refs.email.value,
                mobilenumber: this.refs.mblno.value,
                address: this.refs.addr.value,
                dateofvisit: this.refs.date.value,
                purposeofvisit: this.refs.purpose.value,
            }
        }, function(){
            this.props.onLogIn(this.state.newCust);
        })
    }

    render() {
        return (
            <div class="regForm">
                <form>
                    <h2>Customer Registration Form</h2>
                    <input type="text" placeholder="Username" ref="uname"></input><br/><br/>
                    <input type="text" placeholder="Email Id" ref="email"></input><br/><br/>
                    <input type="text" placeholder="Mobile Number" ref="mblno"></input><br/><br/>
                    <input type="text" placeholder="Address" ref="addr"></input><br/><br/>
                    <input type="text" placeholder="Purpose Of Visit" ref="purpose"></input><br/><br/>
                    <input type="text" placeholder="Date Of Visit" ref="date"></input><br/><br/>
                    <input class="button" type="button" value="Log In" onClick={this.handleClick.bind(this)}></input><br/><br/>
                </form>
            </div>

        );
    }
}

export default RegForm;