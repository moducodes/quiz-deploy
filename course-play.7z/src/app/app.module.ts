import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms'
import { AppRoutingModule } from './app-routing/app-routing.module'

import { AppComponent } from './app.component';
import { CornuComponent } from './cornu/cornu.component';
import { CoursesComponent } from './courses/courses.component';
import { AddcourseComponent } from './addcourse/addcourse.component';
import { GetdurComponent } from './getdur/getdur.component';

@NgModule({
  declarations: [
    AppComponent,
    CornuComponent,
    CoursesComponent,
    AddcourseComponent,
    GetdurComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
