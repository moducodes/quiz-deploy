import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-getdur',
  templateUrl: './getdur.component.html',
  styleUrls: ['./getdur.component.css']
})
export class GetdurComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  queryCourseName: string;
  queryCourseDuration: string;
  @Input() courseList;

  getDuration(){
    this.queryCourseDuration = '';
    for(let i=0; i<this.courseList.length; i++){
      if(this.queryCourseName == this.courseList[i].courseName){
        this.queryCourseDuration = this.courseList[i].courseDuration;
      }
    }
  }
}