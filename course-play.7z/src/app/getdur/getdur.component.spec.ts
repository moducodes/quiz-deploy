import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetdurComponent } from './getdur.component';

describe('GetdurComponent', () => {
  let component: GetdurComponent;
  let fixture: ComponentFixture<GetdurComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetdurComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetdurComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
