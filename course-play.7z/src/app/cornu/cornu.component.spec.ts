import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CornuComponent } from './cornu.component';

describe('CornuComponent', () => {
  let component: CornuComponent;
  let fixture: ComponentFixture<CornuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CornuComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CornuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
