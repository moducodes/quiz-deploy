import { Component, OnInit } from '@angular/core';
import { CoursesComponent } from '../courses/courses.component'

@Component({
  selector: 'app-cornu',
  templateUrl: './cornu.component.html',
  styleUrls: ['./cornu.component.css']
})
export class CornuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
