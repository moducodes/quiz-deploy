import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-courses',
  templateUrl: './courses.component.html',
  styleUrls: ['./courses.component.css']
})
export class CoursesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  courses: object[] = [
    {
      courseName: 'Course 1',
      courseDuration: '2hrs'
    },
    {
      courseName: 'Course 2',
      courseDuration: '13hrs'
    },
    {
      courseName: 'Course 3',
      courseDuration: '12hrs'
    },
    {
      courseName: 'Course 4',
      courseDuration: '9hrs'
    },
    {
      courseName: 'Course 5',
      courseDuration: '18hrs'
    }
  ];

  addCourse(newCourse: object){
    this.courses.push(newCourse);
  }

}
