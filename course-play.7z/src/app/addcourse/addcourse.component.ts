import { Component, OnInit, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-addcourse',
  templateUrl: './addcourse.component.html',
  styleUrls: ['./addcourse.component.css']
})
export class AddcourseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  newCourseName: string = '';
  newCourseDuration: string = '';
  showValidations: boolean[] = [false, false];
  @Output() addCourseClicked: EventEmitter<object> = new EventEmitter<object>();

  addCourse(){
    console.log('addCourse() works!');
    if(this.newCourseName == '' || this.newCourseDuration == ''){
      if(this.newCourseName == ''){
        this.showValidations[0] = true;
      }
      if(this.newCourseDuration == ''){
        this.showValidations[1] = true;
      }
    }
    else{
      let newCourse = {
        courseName: this.newCourseName,
        courseDuration: this.newCourseDuration
      }
      this.addCourseClicked.emit(newCourse);
    }
  }
}
